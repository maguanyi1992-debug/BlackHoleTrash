package com.maguanyi.blackholewallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int REQUEST_BACKGROUND = 1001;
    private SharedPreferences prefs;
    private ImageView backgroundPreview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BlackHolePreferences.ensureDefaults(this);
        prefs = BlackHolePreferences.get(this);

        getWindow().setStatusBarColor(Color.rgb(11, 13, 18));
        getWindow().setNavigationBarColor(Color.rgb(11, 13, 18));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(11, 13, 18));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(32));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("黑洞动态壁纸", 28, Color.WHITE);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView subtitle = text(
                "只运行在桌面背景层，不覆盖其他应用。第一版采用移动端优化着色器，保留吸积盘、引力透镜、8 套预设、漂移、Spin 和触摸互动。",
                15,
                Color.rgb(190, 195, 207));
        subtitle.setPadding(0, dp(8), 0, dp(18));
        root.addView(subtitle);

        backgroundPreview = new ImageView(this);
        backgroundPreview.setBackgroundColor(Color.rgb(23, 27, 37));
        backgroundPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(180));
        previewParams.bottomMargin = dp(10);
        root.addView(backgroundPreview, previewParams);
        refreshPreview();

        Button chooseBackground = button("选择背景图片");
        chooseBackground.setOnClickListener(v -> chooseBackground());
        root.addView(chooseBackground, buttonParams());

        addSectionTitle(root, "黑洞外观");
        Spinner presetSpinner = spinner(Preset.NAMES);
        presetSpinner.setSelection(clamp(prefs.getInt(BlackHolePreferences.KEY_PRESET, 1), 0, Preset.NAMES.length - 1));
        presetSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position ->
                prefs.edit().putInt(BlackHolePreferences.KEY_PRESET, position).apply()));
        root.addView(presetSpinner, fieldParams());

        addSeekBar(
                root,
                "黑洞大小",
                6,
                18,
                Math.round(prefs.getFloat(BlackHolePreferences.KEY_SIZE, 0.115f) * 100f),
                value -> String.format(Locale.US, "%.2f", value / 100f),
                value -> prefs.edit().putFloat(BlackHolePreferences.KEY_SIZE, value / 100f).apply());

        addSeekBar(
                root,
                "Spin",
                0,
                98,
                Math.round(prefs.getFloat(BlackHolePreferences.KEY_SPIN, 0.15f) * 100f),
                value -> String.format(Locale.US, "%.2f", value / 100f),
                value -> prefs.edit().putFloat(BlackHolePreferences.KEY_SPIN, value / 100f).apply());

        addSectionTitle(root, "运动与性能");

        Switch driftSwitch = switchView("自动漂移");
        driftSwitch.setChecked(prefs.getBoolean(BlackHolePreferences.KEY_DRIFT_ENABLED, true));
        driftSwitch.setOnCheckedChangeListener((buttonView, checked) ->
                prefs.edit().putBoolean(BlackHolePreferences.KEY_DRIFT_ENABLED, checked).apply());
        root.addView(driftSwitch, fieldParams());

        addSeekBar(
                root,
                "漂移速度",
                20,
                220,
                Math.round(prefs.getFloat(BlackHolePreferences.KEY_DRIFT_SPEED, 1.0f) * 100f),
                value -> String.format(Locale.US, "%.2fx", value / 100f),
                value -> prefs.edit().putFloat(BlackHolePreferences.KEY_DRIFT_SPEED, value / 100f).apply());

        Spinner fpsSpinner = spinner(new String[]{"省电：30 FPS", "流畅：60 FPS"});
        fpsSpinner.setSelection(prefs.getInt(BlackHolePreferences.KEY_FPS, 30) >= 60 ? 1 : 0);
        fpsSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position ->
                prefs.edit().putInt(BlackHolePreferences.KEY_FPS, position == 1 ? 60 : 30).apply()));
        root.addView(fpsSpinner, fieldParams());

        Switch touchSwitch = switchView("触摸引力与涟漪");
        touchSwitch.setChecked(prefs.getBoolean(BlackHolePreferences.KEY_TOUCH, true));
        touchSwitch.setOnCheckedChangeListener((buttonView, checked) ->
                prefs.edit().putBoolean(BlackHolePreferences.KEY_TOUCH, checked).apply());
        root.addView(touchSwitch, fieldParams());

        Button setWallpaper = button("预览并设为动态壁纸");
        setWallpaper.setTextColor(Color.BLACK);
        setWallpaper.setBackgroundColor(Color.rgb(235, 168, 76));
        setWallpaper.setOnClickListener(v -> openWallpaperPreview());
        LinearLayout.LayoutParams setParams = buttonParams();
        setParams.topMargin = dp(22);
        root.addView(setWallpaper, setParams);

        Button reset = button("恢复默认设置");
        reset.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            BlackHolePreferences.ensureDefaults(this);
            recreate();
        });
        root.addView(reset, buttonParams());

        TextView note = text(
                "提示：不同手机桌面对动态壁纸触摸事件的转发程度不同。壁纸不可见时渲染线程会暂停，以降低耗电。",
                13,
                Color.rgb(150, 156, 170));
        note.setPadding(0, dp(16), 0, 0);
        root.addView(note);

        setContentView(scroll);
    }

    private void chooseBackground() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_BACKGROUND);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_BACKGROUND || resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
            // Some document providers grant a session permission only. The image still works for this run.
        }
        prefs.edit().putString(BlackHolePreferences.KEY_BACKGROUND_URI, uri.toString()).apply();
        refreshPreview();
    }

    private void refreshPreview() {
        String value = prefs == null ? null : prefs.getString(BlackHolePreferences.KEY_BACKGROUND_URI, null);
        if (value == null || value.isEmpty()) {
            backgroundPreview.setImageDrawable(getDrawable(com.maguanyi.blackholewallpaper.R.drawable.wallpaper_thumbnail));
            return;
        }
        try {
            backgroundPreview.setImageURI(Uri.parse(value));
        } catch (RuntimeException exception) {
            backgroundPreview.setImageDrawable(getDrawable(com.maguanyi.blackholewallpaper.R.drawable.wallpaper_thumbnail));
        }
    }

    private void openWallpaperPreview() {
        ComponentName component = new ComponentName(this, BlackHoleWallpaperService.class);
        Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component);
        try {
            startActivity(intent);
        } catch (RuntimeException exception) {
            Intent fallback = new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER);
            try {
                startActivity(fallback);
            } catch (RuntimeException second) {
                Toast.makeText(this, "当前系统禁止更换动态壁纸，请在系统壁纸设置中选择。", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }
    }

    private void addSectionTitle(LinearLayout root, String label) {
        TextView text = text(label, 18, Color.WHITE);
        text.setTypeface(text.getTypeface(), android.graphics.Typeface.BOLD);
        text.setPadding(0, dp(22), 0, dp(8));
        root.addView(text);
    }

    private void addSeekBar(
            LinearLayout root,
            String label,
            int min,
            int max,
            int initial,
            ValueFormatter formatter,
            ValueConsumer consumer) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.setBackgroundColor(Color.rgb(23, 27, 37));

        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = text(label, 15, Color.WHITE);
        TextView value = text(formatter.format(initial), 14, Color.rgb(235, 168, 76));
        value.setGravity(Gravity.END);
        line.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        line.addView(value, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(line);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(max - min);
        seekBar.setProgress(clamp(initial, min, max) - min);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int actual = progress + min;
                value.setText(formatter.format(actual));
                if (fromUser) {
                    consumer.accept(actual);
                }
            }

            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        box.addView(seekBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(box, fieldParams());
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                values) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Color.WHITE);
                view.setTextSize(15);
                view.setPadding(dp(12), dp(12), dp(12), dp(12));
                return view;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(Color.BLACK);
                view.setTextSize(15);
                view.setPadding(dp(12), dp(12), dp(12), dp(12));
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackgroundColor(Color.rgb(23, 27, 37));
        return spinner;
    }

    private Switch switchView(String label) {
        Switch view = new Switch(this);
        view.setText(label);
        view.setTextColor(Color.WHITE);
        view.setTextSize(15);
        view.setPadding(dp(12), dp(10), dp(12), dp(10));
        view.setBackgroundColor(Color.rgb(23, 27, 37));
        return view;
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setBackgroundColor(Color.rgb(37, 42, 55));
        return button;
    }

    private TextView text(String value, int sp, int color) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(sp);
        text.setTextColor(color);
        text.setLineSpacing(0f, 1.2f);
        return text;
    }

    private LinearLayout.LayoutParams fieldParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = dp(10);
        return params;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams params = fieldParams();
        params.height = dp(52);
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private interface ValueFormatter {
        String format(int value);
    }

    private interface ValueConsumer {
        void accept(int value);
    }

    private interface PositionConsumer {
        void accept(int position);
    }

    private static final class SimpleItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {
        private final PositionConsumer consumer;

        private SimpleItemSelectedListener(PositionConsumer consumer) {
            this.consumer = consumer;
        }

        @Override
        public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
            consumer.accept(position);
        }

        @Override
        public void onNothingSelected(android.widget.AdapterView<?> parent) {}
    }
}
