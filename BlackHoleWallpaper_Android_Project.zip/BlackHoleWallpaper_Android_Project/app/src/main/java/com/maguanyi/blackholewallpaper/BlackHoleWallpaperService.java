package com.maguanyi.blackholewallpaper;

import android.service.wallpaper.WallpaperService;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

public final class BlackHoleWallpaperService extends WallpaperService {
    @Override
    public Engine onCreateEngine() {
        BlackHolePreferences.ensureDefaults(this);
        return new BlackHoleEngine();
    }

    private final class BlackHoleEngine extends Engine {
        private BlackHoleRenderer renderer;
        private int width = 1;
        private int height = 1;

        BlackHoleEngine() {
            setTouchEventsEnabled(true);
            setOffsetNotificationsEnabled(true);
        }

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            stopRenderer();
            renderer = new BlackHoleRenderer(getApplicationContext(), holder.getSurface());
            renderer.setSurfaceSize(width, height);
            renderer.start();
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int newWidth, int newHeight) {
            super.onSurfaceChanged(holder, format, newWidth, newHeight);
            width = Math.max(1, newWidth);
            height = Math.max(1, newHeight);
            if (renderer != null) {
                renderer.setSurfaceSize(width, height);
            }
        }

        @Override
        public void onSurfaceRedrawNeeded(SurfaceHolder holder) {
            super.onSurfaceRedrawNeeded(holder);
            if (renderer != null) {
                renderer.requestImmediateFrame();
            }
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            super.onVisibilityChanged(visible);
            if (renderer != null) {
                renderer.setVisible(visible);
            }
        }

        @Override
        public void onOffsetsChanged(
                float xOffset,
                float yOffset,
                float xOffsetStep,
                float yOffsetStep,
                int xPixelOffset,
                int yPixelOffset) {
            super.onOffsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset);
            if (renderer != null) {
                renderer.setWallpaperOffset(xOffset, yOffset);
            }
        }

        @Override
        public void onZoomChanged(float zoom) {
            super.onZoomChanged(zoom);
            if (renderer != null) {
                renderer.setZoom(zoom);
            }
        }

        @Override
        public void onTouchEvent(MotionEvent event) {
            super.onTouchEvent(event);
            if (renderer == null || width <= 0 || height <= 0) {
                return;
            }
            float x = event.getX() / width;
            float y = 1.0f - event.getY() / height;
            boolean active = event.getActionMasked() != MotionEvent.ACTION_UP
                    && event.getActionMasked() != MotionEvent.ACTION_CANCEL;
            renderer.setTouch(x, y, active);
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            stopRenderer();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            stopRenderer();
            super.onDestroy();
        }

        private void stopRenderer() {
            BlackHoleRenderer current = renderer;
            renderer = null;
            if (current != null) {
                current.shutdown();
                try {
                    current.join(1200L);
                } catch (InterruptedException interruptedException) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}
