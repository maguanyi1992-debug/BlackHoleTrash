package com.maguanyi.blackholewallpaper;

import android.content.Context;
import android.content.SharedPreferences;

public final class BlackHolePreferences {
    public static final String FILE = "black_hole_wallpaper_settings";
    public static final String KEY_PRESET = "preset";
    public static final String KEY_SIZE = "size";
    public static final String KEY_DRIFT_SPEED = "drift_speed";
    public static final String KEY_DRIFT_ENABLED = "drift_enabled";
    public static final String KEY_SPIN = "spin";
    public static final String KEY_FPS = "fps";
    public static final String KEY_TOUCH = "touch";
    public static final String KEY_BACKGROUND_URI = "background_uri";

    private BlackHolePreferences() {}

    public static SharedPreferences get(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static void ensureDefaults(Context context) {
        SharedPreferences prefs = get(context);
        if (prefs.contains(KEY_PRESET)) {
            return;
        }
        prefs.edit()
                .putInt(KEY_PRESET, 1)
                .putFloat(KEY_SIZE, 0.115f)
                .putFloat(KEY_DRIFT_SPEED, 1.0f)
                .putBoolean(KEY_DRIFT_ENABLED, true)
                .putFloat(KEY_SPIN, 0.15f)
                .putInt(KEY_FPS, 30)
                .putBoolean(KEY_TOUCH, true)
                .apply();
    }
}
