package com.maguanyi.blackholewallpaper;

public final class Preset {
    public static final String[] NAMES = {
            "Inferno",
            "Gargantua",
            "Quasar",
            "M87* Donut",
            "Blazar",
            "Face-on Ember",
            "Pure Lens",
            "Zen"
    };

    // temp, incl, roll, inner, outer, opacity, doppler, beam,
    // gain, contrast, wind, speed, exposure, star
    public static final float[][] VALUES = {
            {5500f, 1.50f, 0.35f, 1.8f, 8.0f, 0.90f, 0.60f, 2.5f, 2.2f, 1.6f, 7.0f, 5.0f, 1.40f, 0.0f},
            {4500f, 1.52f, 0.10f, 2.2f, 7.0f, 0.85f, 0.35f, 2.0f, 1.4f, 0.5f, 7.0f, 5.0f, 1.20f, 0.0f},
            {15000f, 1.30f, 0.35f, 3.0f, 14.0f, 0.35f, 1.00f, 4.0f, 1.2f, 1.3f, 8.0f, 5.0f, 0.80f, 0.0f},
            {3800f, 0.55f, -0.30f, 2.2f, 6.0f, 0.45f, 0.90f, 3.5f, 1.6f, 0.4f, 3.0f, 2.5f, 1.10f, 0.0f},
            {18000f, 1.05f, 0.55f, 3.0f, 16.0f, 0.30f, 1.00f, 5.0f, 1.0f, 1.5f, 9.0f, 6.0f, 0.75f, 0.0f},
            {6500f, 0.30f, 0.00f, 3.0f, 10.0f, 0.50f, 0.80f, 2.5f, 1.0f, 1.1f, 7.0f, 5.0f, 1.00f, 0.0f},
            {5500f, 1.50f, 0.35f, 1.8f, 8.0f, 0.00f, 1.00f, 2.5f, 0.0f, 1.6f, 7.0f, 5.0f, 1.00f, 0.6f},
            {7000f, 1.45f, 0.15f, 3.5f, 7.0f, 0.40f, 0.50f, 2.0f, 0.5f, 0.3f, 3.0f, 1.5f, 0.70f, 0.0f}
    };

    private Preset() {}
}
