package com.maguanyi.blackholewallpaper;

final class Shaders {
    static final String VERTEX = """
            #version 300 es
            precision highp float;
            out vec2 vUv;
            void main() {
                vec2 position;
                if (gl_VertexID == 0) {
                    position = vec2(-1.0, -1.0);
                } else if (gl_VertexID == 1) {
                    position = vec2(3.0, -1.0);
                } else {
                    position = vec2(-1.0, 3.0);
                }
                vUv = vec2(position.x * 0.5 + 0.5, position.y * 0.5 + 0.5);
                gl_Position = vec4(position, 0.0, 1.0);
            }
            """;

    static final String FRAGMENT = """
            #version 300 es
            precision highp float;
            precision highp int;

            in vec2 vUv;
            out vec4 fragColor;

            uniform sampler2D uBackground;
            uniform int uHasTexture;
            uniform vec2 uResolution;
            uniform vec2 uTextureSize;
            uniform float uTime;
            uniform float uRadius;
            uniform float uDriftSpeed;
            uniform float uDriftEnabled;
            uniform float uSpin;
            uniform vec2 uTouch;
            uniform float uTouchStrength;
            uniform float uWallpaperOffset;
            uniform float uZoom;
            uniform vec4 uLookA;
            uniform vec4 uLookB;
            uniform vec4 uLookC;
            uniform vec2 uLookD;

            const float PI = 3.141592653589793;
            const float TAU = 6.283185307179586;

            float saturate(float x) {
                return clamp(x, 0.0, 1.0);
            }

            vec2 rotate2(vec2 p, float angle) {
                float c = cos(angle);
                float s = sin(angle);
                return mat2(c, -s, s, c) * p;
            }

            float hash21(vec2 p) {
                p = fract(p * vec2(234.34, 435.345));
                p += dot(p, p + 34.23);
                return fract(p.x * p.y);
            }

            float noise2(vec2 p) {
                vec2 i = floor(p);
                vec2 f = fract(p);
                f = f * f * (3.0 - 2.0 * f);
                float a = hash21(i);
                float b = hash21(i + vec2(1.0, 0.0));
                float c = hash21(i + vec2(0.0, 1.0));
                float d = hash21(i + vec2(1.0, 1.0));
                return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
            }

            float fbm(vec2 p) {
                float value = 0.0;
                float amplitude = 0.55;
                for (int i = 0; i < 4; i++) {
                    value += noise2(p) * amplitude;
                    p = p * 2.03 + vec2(13.7, 7.1);
                    amplitude *= 0.48;
                }
                return value;
            }

            vec3 blackbody(float kelvin) {
                float t = clamp(kelvin, 1500.0, 40000.0) / 100.0;
                float r = 1.0;
                if (t > 66.0) {
                    r = clamp(1.292936 * pow(t - 60.0, -0.1332047), 0.0, 1.0);
                }
                float g;
                if (t <= 66.0) {
                    g = clamp(0.3900816 * log(t) - 0.6318414, 0.0, 1.0);
                } else {
                    g = clamp(1.1298909 * pow(t - 60.0, -0.0755148), 0.0, 1.0);
                }
                float b = 1.0;
                if (t < 66.0) {
                    if (t <= 19.0) {
                        b = 0.0;
                    } else {
                        b = clamp(0.5432068 * log(t - 10.0) - 1.1962540, 0.0, 1.0);
                    }
                }
                return vec3(r, g, b);
            }

            vec3 proceduralBackground(vec2 uv) {
                vec2 centered = uv - 0.5;
                float radial = length(centered);
                vec3 top = vec3(0.055, 0.075, 0.13);
                vec3 bottom = vec3(0.008, 0.012, 0.025);
                vec3 color = mix(bottom, top, smoothstep(0.0, 1.0, uv.y));
                color *= 1.0 - radial * 0.42;
                vec2 cell = floor(uv * vec2(64.0, 112.0));
                float h = hash21(cell);
                float star = step(0.982, h) * pow(h, 14.0);
                color += vec3(0.75, 0.82, 1.0) * star * 1.6;
                return color;
            }

            vec2 coverUv(vec2 uv) {
                if (uHasTexture == 0 || uTextureSize.x < 1.0 || uTextureSize.y < 1.0) {
                    return uv;
                }
                float screenAspect = uResolution.x / max(uResolution.y, 1.0);
                float textureAspect = uTextureSize.x / max(uTextureSize.y, 1.0);
                vec2 outUv = uv;
                if (screenAspect > textureAspect) {
                    float scale = textureAspect / screenAspect;
                    outUv.y = (outUv.y - 0.5) * scale + 0.5;
                } else {
                    float scale = screenAspect / textureAspect;
                    outUv.x = (outUv.x - 0.5) * scale + 0.5;
                }
                outUv.x += (uWallpaperOffset - 0.5) * 0.08;
                return clamp(outUv, 0.001, 0.999);
            }

            vec3 background(vec2 uv) {
                if (uHasTexture == 0) {
                    return proceduralBackground(uv);
                }
                return texture(uBackground, coverUv(uv)).rgb;
            }

            vec3 starField(vec2 direction) {
                vec2 grid = direction * vec2(44.0, 76.0);
                vec2 id = floor(grid);
                vec2 f = fract(grid) - 0.5;
                float h = hash21(id);
                vec2 offset = vec2(hash21(id + 11.7), hash21(id + 27.1)) - 0.5;
                float spark = smoothstep(0.09, 0.0, length(f - offset * 0.65));
                float twinkle = 0.72 + 0.28 * sin(uTime * (0.5 + h * 2.0) + h * 30.0);
                vec3 tint = mix(vec3(1.0, 0.82, 0.62), vec3(0.72, 0.84, 1.0), hash21(id + 5.3));
                return tint * spark * step(0.93, h) * twinkle * ((h - 0.93) / 0.07);
            }

            vec2 driftCenter(float timeValue) {
                float t = timeValue * 0.12 * max(uDriftSpeed, 0.05);
                float x = 0.75 * sin(t * 0.37) + 0.25 * sin(t * 0.83 + 1.0);
                float y = 0.70 * sin(t * 0.54 + 2.1) + 0.30 * sin(t * 1.07);
                return vec2(0.5 + x * 0.20, 0.5 + y * 0.14);
            }

            void main() {
                float temp = uLookA.x;
                float inclination = uLookA.y;
                float roll = uLookA.z;
                float innerEdge = uLookA.w;
                float outerEdge = uLookB.x;
                float opacity = uLookB.y;
                float dopplerMix = uLookB.z;
                float beaming = uLookB.w;
                float gain = uLookC.x;
                float contrast = uLookC.y;
                float winding = uLookC.z;
                float diskSpeed = uLookC.w;
                float exposure = uLookD.x;
                float starGain = uLookD.y;

                float aspect = uResolution.x / max(uResolution.y, 1.0);
                vec2 center = mix(vec2(0.5), driftCenter(uTime), uDriftEnabled);
                float touchDistance = distance(uTouch, center);
                float touchPull = uTouchStrength * smoothstep(0.75, 0.04, touchDistance) * 0.22;
                center = mix(center, uTouch, touchPull);

                vec2 p = vUv - center;
                p.x *= aspect;
                float radius = max(uRadius * mix(0.92, 1.08, uZoom), 0.035);
                float r = length(p) / radius;
                float angle = atan(p.y, p.x);

                float horizon = 1.0 - smoothstep(0.90, 1.02, r);
                float nearRing = exp(-pow((r - 1.09) / 0.055, 2.0));
                float farRing = exp(-pow((r - 1.28) / 0.11, 2.0));

                float inverseR = 1.0 / max(r, 0.15);
                float bend = 0.20 * inverseR * inverseR + 0.035 * inverseR;
                float twist = uSpin * (0.62 * inverseR + 0.16 * inverseR * inverseR);
                vec2 lensed = rotate2(p, twist) * (1.0 + bend);
                vec2 sampleUv = center + vec2(lensed.x / aspect, lensed.y);
                vec3 color = background(sampleUv);

                vec2 skyDirection = vec2(angle / TAU + 0.5, clamp(r * 0.11, 0.0, 1.0));
                color += starField(skyDirection + vec2(twist * 0.04, 0.0)) * starGain;

                vec2 diskP = rotate2(p, -roll);
                float cosIncl = max(abs(cos(inclination)), 0.055);
                vec2 diskSpace = vec2(diskP.x, diskP.y / cosIncl);
                float diskRadius = length(diskSpace) / radius;
                float diskAngle = atan(diskSpace.y, diskSpace.x);

                float mappedInner = max(1.18, innerEdge * 0.62);
                float mappedOuter = max(mappedInner + 0.7, outerEdge * 0.62);
                float radialBand = smoothstep(mappedInner, mappedInner + 0.45, diskRadius)
                        * (1.0 - smoothstep(mappedOuter * 0.78, mappedOuter, diskRadius));
                float thickness = mix(0.045, 0.22, cosIncl);
                float planeBand = exp(-abs(diskP.y) / max(radius * thickness, 0.001));

                float orbit = diskAngle / TAU;
                float timeFlow = uTime * diskSpeed * 0.075;
                float spiral = diskRadius * winding * 0.55 - timeFlow / max(pow(diskRadius, 1.25), 0.5);
                float streak = fbm(vec2(diskRadius * 1.65, orbit * 21.0 + spiral));
                streak = 0.28 + contrast * streak * streak;

                float hotProfile = pow(max(mappedInner / max(diskRadius, mappedInner), 0.01), 0.72);
                hotProfile *= pow(max(1.0 - sqrt(mappedInner / max(diskRadius, mappedInner + 0.001)), 0.0), 0.24);
                hotProfile = clamp(hotProfile * 2.25, 0.0, 1.0);

                float orbitalSide = cos(diskAngle);
                float shift = mix(1.0, clamp(1.0 + orbitalSide * 0.45, 0.55, 1.55), dopplerMix);
                vec3 diskColor = blackbody(temp * max(hotProfile, 0.25) * shift);
                float boost = pow(max(shift, 0.05), beaming);
                float diskMask = radialBand * planeBand * streak;
                diskMask *= smoothstep(0.82, 1.08, r);
                diskMask *= 1.0 - horizon;

                float upperArc = exp(-pow((r - 1.34) / 0.10, 2.0))
                        * exp(-abs(diskP.y + radius * 0.20) / max(radius * 0.09, 0.001));
                float lowerArc = exp(-pow((r - 1.18) / 0.07, 2.0))
                        * exp(-abs(diskP.y - radius * 0.13) / max(radius * 0.07, 0.001));
                float lensedArc = (upperArc + lowerArc * 0.65) * radialBand;

                vec3 emission = diskColor * gain * (diskMask * 1.65 + lensedArc * 0.75) * boost;
                color = mix(color, color * (1.0 - opacity * diskMask * 0.35), diskMask);
                color += emission;

                vec3 photonColor = mix(vec3(1.0, 0.52, 0.16), blackbody(temp), 0.48);
                color += photonColor * nearRing * (0.55 + gain * 0.32);
                color += photonColor * farRing * 0.10 * (1.0 + uSpin);

                float touchRadius = distance(vUv, uTouch);
                float touchRipple = sin(touchRadius * 95.0 - uTime * 8.0)
                        * exp(-touchRadius * 12.0)
                        * uTouchStrength;
                color += vec3(1.0, 0.55, 0.18) * max(touchRipple, 0.0) * 0.22;

                color = mix(color, vec3(0.0), horizon);
                float innerGlow = exp(-pow((r - 0.98) / 0.035, 2.0));
                color += photonColor * innerGlow * 0.28 * (1.0 - horizon);

                color = vec3(1.0) - exp(-max(color, vec3(0.0)) * max(exposure, 0.25));
                color = pow(color, vec3(1.0 / 2.2));
                fragColor = vec4(color, 1.0);
            }
            """;

    private Shaders() {}
}
