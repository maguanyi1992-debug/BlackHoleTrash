package com.maguanyi.blackholewallpaper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES30;
import android.opengl.GLUtils;
import android.util.Log;
import android.view.Surface;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;

final class BlackHoleRenderer extends Thread {
    private static final String TAG = "BlackHoleRenderer";
    private static final int EGL_OPENGL_ES3_BIT_KHR = 0x0040;
    private static final long SETTINGS_REFRESH_NS = 500_000_000L;

    private final Context context;
    private final Surface surface;
    private final SharedPreferences preferences;
    private final AtomicBoolean running = new AtomicBoolean(true);

    private volatile boolean visible = true;
    private volatile boolean immediateFrame = true;
    private volatile int width = 1;
    private volatile int height = 1;
    private volatile float touchX = 0.5f;
    private volatile float touchY = 0.5f;
    private volatile boolean touchActive = false;
    private volatile float wallpaperOffset = 0.5f;
    private volatile float zoom = 1.0f;

    private EGLDisplay eglDisplay = EGL14.EGL_NO_DISPLAY;
    private EGLContext eglContext = EGL14.EGL_NO_CONTEXT;
    private EGLSurface eglSurface = EGL14.EGL_NO_SURFACE;

    private int program;
    private int vertexArray;
    private int backgroundTexture;
    private int hasTexture;
    private int textureWidth = 1;
    private int textureHeight = 1;
    private String loadedBackgroundUri = "";

    private int presetIndex = 1;
    private float radius = 0.115f;
    private float driftSpeed = 1.0f;
    private boolean driftEnabled = true;
    private float spin = 0.15f;
    private int fps = 30;
    private boolean touchEnabled = true;
    private float touchStrength = 0.0f;

    private final float[] currentLook = Arrays.copyOf(Preset.VALUES[1], 14);
    private final float[] targetLook = Arrays.copyOf(Preset.VALUES[1], 14);

    private long startTimeNs;
    private long lastSettingsReadNs;
    private long lastFrameNs;

    BlackHoleRenderer(Context context, Surface surface) {
        super("BlackHoleWallpaper-GL");
        this.context = context.getApplicationContext();
        this.surface = surface;
        this.preferences = BlackHolePreferences.get(context);
    }

    void setSurfaceSize(int width, int height) {
        this.width = Math.max(1, width);
        this.height = Math.max(1, height);
        immediateFrame = true;
    }

    void setVisible(boolean visible) {
        this.visible = visible;
        immediateFrame = true;
        if (visible) {
            interrupt();
        }
    }

    void setTouch(float x, float y, boolean active) {
        touchX = clamp(x, 0.0f, 1.0f);
        touchY = clamp(y, 0.0f, 1.0f);
        touchActive = active;
        immediateFrame = true;
    }

    void setWallpaperOffset(float xOffset, float yOffset) {
        wallpaperOffset = clamp(xOffset, 0.0f, 1.0f);
        immediateFrame = true;
    }

    void setZoom(float zoom) {
        this.zoom = clamp(zoom, 0.0f, 1.0f);
        immediateFrame = true;
    }

    void requestImmediateFrame() {
        immediateFrame = true;
        interrupt();
    }

    void shutdown() {
        running.set(false);
        interrupt();
    }

    @Override
    public void run() {
        try {
            initializeEgl();
            initializeGl();
            startTimeNs = System.nanoTime();
            lastFrameNs = startTimeNs;
            readSettings(true);

            while (running.get()) {
                if (!visible || !surface.isValid()) {
                    sleepQuietly(120L);
                    continue;
                }

                long frameStartNs = System.nanoTime();
                readSettings(false);
                updateAnimatedState(frameStartNs);
                drawFrame(frameStartNs);

                if (!EGL14.eglSwapBuffers(eglDisplay, eglSurface)) {
                    int error = EGL14.eglGetError();
                    Log.e(TAG, "eglSwapBuffers failed: 0x" + Integer.toHexString(error));
                    if (error == EGL14.EGL_BAD_SURFACE || error == EGL14.EGL_BAD_NATIVE_WINDOW) {
                        break;
                    }
                }

                immediateFrame = false;
                int currentFps = Math.max(1, fps);
                long targetNs = 1_000_000_000L / currentFps;
                long elapsedNs = System.nanoTime() - frameStartNs;
                long sleepNs = targetNs - elapsedNs;
                if (sleepNs > 0L && !immediateFrame) {
                    sleepNanos(sleepNs);
                }
            }
        } catch (RuntimeException exception) {
            Log.e(TAG, "Renderer stopped because of an unrecoverable error", exception);
        } finally {
            releaseGl();
            releaseEgl();
        }
    }

    private void initializeEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) {
            throw new IllegalStateException("Unable to obtain EGL display");
        }

        int[] version = new int[2];
        if (!EGL14.eglInitialize(eglDisplay, version, 0, version, 1)) {
            throw new IllegalStateException("Unable to initialize EGL");
        }

        int[] attributes = {
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
                EGL14.EGL_NONE
        };
        EGLConfig[] configs = new EGLConfig[1];
        int[] count = new int[1];
        if (!EGL14.eglChooseConfig(eglDisplay, attributes, 0, configs, 0, 1, count, 0) || count[0] == 0) {
            throw new IllegalStateException("No OpenGL ES 3 EGL config available");
        }

        int[] contextAttributes = {
                EGL14.EGL_CONTEXT_CLIENT_VERSION, 3,
                EGL14.EGL_NONE
        };
        eglContext = EGL14.eglCreateContext(
                eglDisplay,
                configs[0],
                EGL14.EGL_NO_CONTEXT,
                contextAttributes,
                0);
        if (eglContext == EGL14.EGL_NO_CONTEXT) {
            throw new IllegalStateException("Unable to create OpenGL ES 3 context");
        }

        int[] surfaceAttributes = {EGL14.EGL_NONE};
        eglSurface = EGL14.eglCreateWindowSurface(
                eglDisplay,
                configs[0],
                surface,
                surfaceAttributes,
                0);
        if (eglSurface == EGL14.EGL_NO_SURFACE) {
            throw new IllegalStateException("Unable to create EGL window surface");
        }

        if (!EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)) {
            throw new IllegalStateException("Unable to make EGL context current");
        }

        EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, System.nanoTime());
        Log.i(TAG, "OpenGL renderer: " + GLES30.glGetString(GLES30.GL_RENDERER));
    }

    private void initializeGl() {
        int vertexShader = compileShader(GLES30.GL_VERTEX_SHADER, Shaders.VERTEX);
        int fragmentShader = compileShader(GLES30.GL_FRAGMENT_SHADER, Shaders.FRAGMENT);

        program = GLES30.glCreateProgram();
        GLES30.glAttachShader(program, vertexShader);
        GLES30.glAttachShader(program, fragmentShader);
        GLES30.glLinkProgram(program);

        int[] status = new int[1];
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0);
        String log = GLES30.glGetProgramInfoLog(program);
        GLES30.glDeleteShader(vertexShader);
        GLES30.glDeleteShader(fragmentShader);
        if (status[0] == 0) {
            GLES30.glDeleteProgram(program);
            program = 0;
            throw new IllegalStateException("Program link failed: " + log);
        }

        int[] vao = new int[1];
        GLES30.glGenVertexArrays(1, vao, 0);
        vertexArray = vao[0];
        GLES30.glBindVertexArray(vertexArray);

        createFallbackTexture();
        GLES30.glDisable(GLES30.GL_DEPTH_TEST);
        GLES30.glDisable(GLES30.GL_CULL_FACE);
        GLES30.glDisable(GLES30.GL_BLEND);
    }

    private int compileShader(int type, String source) {
        int shader = GLES30.glCreateShader(type);
        GLES30.glShaderSource(shader, source);
        GLES30.glCompileShader(shader);
        int[] status = new int[1];
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0);
        if (status[0] == 0) {
            String log = GLES30.glGetShaderInfoLog(shader);
            GLES30.glDeleteShader(shader);
            throw new IllegalStateException("Shader compile failed: " + log);
        }
        return shader;
    }

    private void createFallbackTexture() {
        if (backgroundTexture != 0) {
            int[] old = {backgroundTexture};
            GLES30.glDeleteTextures(1, old, 0);
        }
        int[] textures = new int[1];
        GLES30.glGenTextures(1, textures, 0);
        backgroundTexture = textures[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, backgroundTexture);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        byte[] pixel = {8, 12, 24, (byte) 255};
        java.nio.ByteBuffer buffer = java.nio.ByteBuffer.allocateDirect(4);
        buffer.put(pixel).position(0);
        GLES30.glTexImage2D(
                GLES30.GL_TEXTURE_2D,
                0,
                GLES30.GL_RGBA,
                1,
                1,
                0,
                GLES30.GL_RGBA,
                GLES30.GL_UNSIGNED_BYTE,
                buffer);
        hasTexture = 0;
        textureWidth = 1;
        textureHeight = 1;
    }

    private void readSettings(boolean force) {
        long now = System.nanoTime();
        if (!force && now - lastSettingsReadNs < SETTINGS_REFRESH_NS) {
            return;
        }
        lastSettingsReadNs = now;

        int newPreset = clamp(preferences.getInt(BlackHolePreferences.KEY_PRESET, 1), 0, Preset.VALUES.length - 1);
        if (newPreset != presetIndex || force) {
            presetIndex = newPreset;
            System.arraycopy(Preset.VALUES[presetIndex], 0, targetLook, 0, targetLook.length);
            if (force) {
                System.arraycopy(targetLook, 0, currentLook, 0, currentLook.length);
            }
        }

        radius = clamp(preferences.getFloat(BlackHolePreferences.KEY_SIZE, 0.115f), 0.06f, 0.18f);
        driftSpeed = clamp(preferences.getFloat(BlackHolePreferences.KEY_DRIFT_SPEED, 1.0f), 0.2f, 2.2f);
        driftEnabled = preferences.getBoolean(BlackHolePreferences.KEY_DRIFT_ENABLED, true);
        spin = clamp(preferences.getFloat(BlackHolePreferences.KEY_SPIN, 0.15f), 0.0f, 0.98f);
        fps = preferences.getInt(BlackHolePreferences.KEY_FPS, 30) >= 60 ? 60 : 30;
        touchEnabled = preferences.getBoolean(BlackHolePreferences.KEY_TOUCH, true);

        String uriValue = preferences.getString(BlackHolePreferences.KEY_BACKGROUND_URI, "");
        if (force || !uriValue.equals(loadedBackgroundUri)) {
            loadedBackgroundUri = uriValue;
            loadBackground(uriValue);
        }
    }

    private void loadBackground(String uriValue) {
        if (uriValue == null || uriValue.isEmpty()) {
            createFallbackTexture();
            return;
        }

        Bitmap bitmap = decodeSampledBitmap(Uri.parse(uriValue), 2048);
        if (bitmap == null) {
            Log.w(TAG, "Unable to decode selected background; using procedural background");
            createFallbackTexture();
            return;
        }

        if (backgroundTexture == 0) {
            int[] textures = new int[1];
            GLES30.glGenTextures(1, textures, 0);
            backgroundTexture = textures[0];
        }
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, backgroundTexture);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0);
        textureWidth = bitmap.getWidth();
        textureHeight = bitmap.getHeight();
        hasTexture = 1;
        bitmap.recycle();
    }

    private Bitmap decodeSampledBitmap(Uri uri, int maxDimension) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream stream = context.getContentResolver().openInputStream(uri)) {
            if (stream == null) {
                return null;
            }
            BitmapFactory.decodeStream(stream, null, bounds);
        } catch (IOException | SecurityException exception) {
            Log.w(TAG, "Unable to read background bounds", exception);
            return null;
        }

        int sampleSize = 1;
        int largest = Math.max(bounds.outWidth, bounds.outHeight);
        while (largest / sampleSize > maxDimension) {
            sampleSize *= 2;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = Math.max(1, sampleSize);
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (InputStream stream = context.getContentResolver().openInputStream(uri)) {
            if (stream == null) {
                return null;
            }
            return BitmapFactory.decodeStream(stream, null, options);
        } catch (IOException | SecurityException exception) {
            Log.w(TAG, "Unable to decode background", exception);
            return null;
        }
    }

    private void updateAnimatedState(long nowNs) {
        float deltaSeconds = clamp((nowNs - lastFrameNs) / 1_000_000_000.0f, 0.0f, 0.1f);
        lastFrameNs = nowNs;
        float blend = 1.0f - (float) Math.exp(-deltaSeconds * 4.5f);
        for (int index = 0; index < currentLook.length; index++) {
            currentLook[index] += (targetLook[index] - currentLook[index]) * blend;
        }

        float targetStrength = touchEnabled && touchActive ? 1.0f : 0.0f;
        float touchBlend = 1.0f - (float) Math.exp(-deltaSeconds * (targetStrength > touchStrength ? 10.0f : 3.0f));
        touchStrength += (targetStrength - touchStrength) * touchBlend;
    }

    private void drawFrame(long nowNs) {
        float timeSeconds = (nowNs - startTimeNs) / 1_000_000_000.0f;
        GLES30.glViewport(0, 0, width, height);
        GLES30.glUseProgram(program);
        GLES30.glBindVertexArray(vertexArray);

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, backgroundTexture);
        uniform1i("uBackground", 0);
        uniform1i("uHasTexture", hasTexture);
        uniform2f("uResolution", width, height);
        uniform2f("uTextureSize", textureWidth, textureHeight);
        uniform1f("uTime", timeSeconds);
        uniform1f("uRadius", radius);
        uniform1f("uDriftSpeed", driftSpeed);
        uniform1f("uDriftEnabled", driftEnabled ? 1.0f : 0.0f);
        uniform1f("uSpin", spin);
        uniform2f("uTouch", touchX, touchY);
        uniform1f("uTouchStrength", touchEnabled ? touchStrength : 0.0f);
        uniform1f("uWallpaperOffset", wallpaperOffset);
        uniform1f("uZoom", zoom);
        uniform4f("uLookA", currentLook[0], currentLook[1], currentLook[2], currentLook[3]);
        uniform4f("uLookB", currentLook[4], currentLook[5], currentLook[6], currentLook[7]);
        uniform4f("uLookC", currentLook[8], currentLook[9], currentLook[10], currentLook[11]);
        uniform2f("uLookD", currentLook[12], currentLook[13]);

        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
    }

    private void uniform1i(String name, int value) {
        int location = GLES30.glGetUniformLocation(program, name);
        if (location >= 0) {
            GLES30.glUniform1i(location, value);
        }
    }

    private void uniform1f(String name, float value) {
        int location = GLES30.glGetUniformLocation(program, name);
        if (location >= 0) {
            GLES30.glUniform1f(location, value);
        }
    }

    private void uniform2f(String name, float x, float y) {
        int location = GLES30.glGetUniformLocation(program, name);
        if (location >= 0) {
            GLES30.glUniform2f(location, x, y);
        }
    }

    private void uniform4f(String name, float x, float y, float z, float w) {
        int location = GLES30.glGetUniformLocation(program, name);
        if (location >= 0) {
            GLES30.glUniform4f(location, x, y, z, w);
        }
    }

    private void releaseGl() {
        if (backgroundTexture != 0) {
            int[] textures = {backgroundTexture};
            GLES30.glDeleteTextures(1, textures, 0);
            backgroundTexture = 0;
        }
        if (vertexArray != 0) {
            int[] arrays = {vertexArray};
            GLES30.glDeleteVertexArrays(1, arrays, 0);
            vertexArray = 0;
        }
        if (program != 0) {
            GLES30.glDeleteProgram(program);
            program = 0;
        }
    }

    private void releaseEgl() {
        if (eglDisplay == EGL14.EGL_NO_DISPLAY) {
            return;
        }
        EGL14.eglMakeCurrent(
                eglDisplay,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_SURFACE,
                EGL14.EGL_NO_CONTEXT);
        if (eglSurface != EGL14.EGL_NO_SURFACE) {
            EGL14.eglDestroySurface(eglDisplay, eglSurface);
            eglSurface = EGL14.EGL_NO_SURFACE;
        }
        if (eglContext != EGL14.EGL_NO_CONTEXT) {
            EGL14.eglDestroyContext(eglDisplay, eglContext);
            eglContext = EGL14.EGL_NO_CONTEXT;
        }
        EGL14.eglTerminate(eglDisplay);
        eglDisplay = EGL14.EGL_NO_DISPLAY;
    }

    private static void sleepQuietly(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ignored) {
            // Interruption is used to wake the render thread when visibility changes.
        }
    }

    private static void sleepNanos(long nanoseconds) {
        long millis = nanoseconds / 1_000_000L;
        int nanos = (int) (nanoseconds % 1_000_000L);
        try {
            Thread.sleep(millis, nanos);
        } catch (InterruptedException ignored) {
            // A setting or visibility change should wake the renderer immediately.
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
