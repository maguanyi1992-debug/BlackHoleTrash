# BlackHoleWallpaper Android

Android live wallpaper edition of the BlackHoleTrash visual concept.

## Features

- Android `WallpaperService`, so the black hole stays behind launcher icons and never overlays other apps.
- OpenGL ES 3.0 renderer.
- Eight visual presets: Inferno, Gargantua, Quasar, M87* Donut, Blazar, Face-on Ember, Pure Lens and Zen.
- Auto drift, adjustable size, spin and 30/60 FPS.
- Optional touch attraction/ripple.
- User-selected background image through Android's document picker.
- Rendering pauses whenever the wallpaper is not visible.
- No file deletion, recycle-bin feature, storage-management permission, network permission or overlay permission.

## Build

The supplied GitHub Actions workflow builds a signed debug APK for testing. Android Studio can also open this directory directly.

Requirements used by the workflow:

- JDK 17
- Gradle 9.5.0
- Android Gradle Plugin 9.3.0
- Android SDK 36 / Build Tools 36.0.0

## Notes

The first Android release uses a mobile-optimized analytical lensing shader rather than the desktop build's full per-pixel numerical geodesic integration. This reduces heat and battery use while preserving the black-hole shadow, photon ring, accretion disk, Doppler asymmetry, spin, presets and background lensing.
